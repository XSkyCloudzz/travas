await conn.relayMessage(from, { viewOnceMessage: { message: {
  "imageMessage": {
    "url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m269/up-oil-image-43c01f8b-9365-4fd5-8182-e89e3db64a47?ccb=9-4&oh=01_Q5AaILDSDY68ClnqLvO_7hjXh9bNjmRMNkA4Xf5BjeIGZB7o&oe=66B113FE&_nc_sid=000000&mms3=true",
    "mimetype": "image/jpeg",
    "fileSha256": "Ns2zcM9A8Zo1epTGlWLeB1brv+xAGZ0Zsm6LUyMGoJI=",
    "fileLength": "40294",
    "mediaKey": "qh5OV57P0IX5TiQtZVvDkYWCnB+Py20oNX2VMLtBHoc=",
    "fileEncSha256": "gGXStTrHaxxVteuvRAfi2ehk4vllv34fBs05efDFmgQ=",
    "directPath": "/o1/v/t62.7118-24/f1/m269/up-oil-image-43c01f8b-9365-4fd5-8182-e89e3db64a47?ccb=9-4&oh=01_Q5AaILDSDY68ClnqLvO_7hjXh9bNjmRMNkA4Xf5BjeIGZB7o&oe=66B113FE&_nc_sid=000000",
    "mediaKeyTimestamp": "1720292221"
  }
} } }, {});